import subprocess
from datetime import date

from models import funcionario
from models.funcionario import Funcionario
from repositories.funcionario_repository import FuncionarioRepository
"""
def main():
    conexao = Conexao()
    print("\033{32mConexao bem sucedida\033{0m")}})
"""

def main():

    repository = FuncionarioRepository()

    funcionarios = repository.listar()

    if len(funcionarios) == 0:

        print("Nenhum funcionário cadastrado.")

    else:

        for funcionario in funcionarios:

            print(funcionario)

            print("-" * 50)

    repository.fechar()


if __name__ == "__main__":
    main()

