from repositories.funcionario_repository import FuncionarioRepository
from menu import Menu


def main():
    menu = Menu()
    menu.exibir_menu()
    


    

if __name__ == "__main__":
    main()