import os
import psycopg
from dotenv import load_dotenv

load_dotenv() # Carrega automaticamente as variáveis existentes no .env

class Conexao:
    def __init__(self):
        self.host = os.getenv("DB_HOST")
        self.port = int(os.getenv("DB_PORT", 5432))
        self.database = os.getenv("DB_NAME")
        self.user = os.getenv("DB_USER")
        self.password = os.getenv("DB_PASSWORD")

        if self.password is None:
            raise ValueError("DB_PASSWORD não está definido no arquivo .env")
        if not isinstance(self.password, str):
            self.password = str(self.password)

        self.conexao = psycopg.connect(
            host=self.host,
            port=self.port,
            dbname=self.database,
            user=self.user,
            password=self.password,
            connect_timeout=3
        )
        self.cursor = self.conexao.cursor()


    def commit(self):
        self.conexao.commit()
    def rollback(self):
        self.conexao.rollback()
    def fechar(self):
        self.cursor.close()
        self.conexao.close()
        