from database.conexao import Conexao
from datetime import date
from models.funcionario import Funcionario

def main():
    # criação de um objeto funcionario
    funcionario = Funcionario(
        id_funcionario = 1,
        nome = "Gabriel Baptista",
        cpf = "123.545.978-99",
        cargo = "Chefe do peneumoultramicroscopicossilicovulcanoconiótico",
        departamento = "Anticonstitussionalissimamente inconstitucionalissimamente peneumoultramicroscopicossilicovulcanoconiótico",
        salario = 9999999

    )

if __name__ == "__main__":
    main()