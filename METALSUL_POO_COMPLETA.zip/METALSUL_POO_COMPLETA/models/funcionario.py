from database.conexao import Conexao
from datetime import date

class Funcionario:
    def __init__(
        self,
        id_funcionario=None,
        nome="",
        cpf="",
        rg="",
        data_nascimento=None,
        sexo="",
        estado_civil="",
        email="",
        telefone="",
        celular="",
        cargo="",
        departamento="",
        salario=0.0,
        data_admissao=None,
        data_demissao=None,
        turno="",
        status="ATIVO",
        observacoes=""
    ):
        self.id_funcionario = id_funcionario
        self.nome = nome
        self.cpf = cpf
        self.rg = rg
        self.data_nascimento = data_nascimento
        self.sexo = sexo
        self.estado_civil = estado_civil
        self.email = email
        self.telefone = telefone
        self.celular = celular
        self.cargo = cargo
        self.departamento = departamento
        self.salario = salario
        self.data_admissao = data_admissao
        self.data_demissao = data_demissao
        self.turno = turno
        self.status = status
        self.observacoes = observacoes

    def __str__(self):
        return(
            print(f"Funcionário: {self.nome}"),
            print(f"CPF: {self.cpf}"),
            print(f"Cargo: {self.cargo}"),
            print(f"Departamento: {self.departamento}"),
            print(f"Salário: {self.salario}")
        )
