-- ==========================================================
-- POPULAÇÃO - METALSUL
-- ==========================================================

-- ==========================================================
-- FUNCIONARIO
-- ==========================================================

INSERT INTO funcionario
(nome, cpf, rg, data_nascimento, sexo, estado_civil, email,
 telefone, celular, cargo, departamento, salario, data_admissao,
 data_demissao, turno, status, observacoes)
VALUES
('Carlos Eduardo Silva', '11111111101', '123456789', '1990-03-15', 'M', 'CASADO',
 'carlos@metalsul.com', '4730001001', '47990001001', 'Gerente', 'Administrativo', 6500.00, '2020-01-10', NULL, 'Comercial', 'ATIVO', 'Gerente geral'),

('Ana Paula Souza', '11111111102', '123456790', '1995-07-22', 'F', 'SOLTEIRA',
 'ana@metalsul.com', '4730001002', '47990001002', 'Analista', 'Financeiro', 4200.00, '2021-02-15', NULL, 'Comercial', 'ATIVO', NULL),

('Marcos Vinicius Lima', '11111111103', '123456791', '1988-11-10', 'M', 'CASADO',
 'marcos@metalsul.com', '4730001003', '47990001003', 'Operador', 'Produção', 3500.00, '2019-05-20', NULL, 'Manhã', 'ATIVO', NULL),

('Juliana Martins', '11111111104', '123456792', '1997-01-30', 'F', 'SOLTEIRA',
 'juliana@metalsul.com', '4730001004', '47990001004', 'Vendedora', 'Vendas', 3200.00, '2022-03-12', NULL, 'Comercial', 'ATIVO', NULL),

('Rafael Oliveira', '11111111105', '123456793', '1992-09-18', 'M', 'CASADO',
 'rafael@metalsul.com', '4730001005', '47990001005', 'Comprador', 'Compras', 4100.00, '2021-08-01', NULL, 'Comercial', 'ATIVO', NULL),

('Fernanda Costa', '11111111106', '123456794', '1996-05-14', 'F', 'SOLTEIRA',
 'fernanda@metalsul.com', '4730001006', '47990001006', 'Assistente', 'RH', 3000.00, '2023-01-09', NULL, 'Comercial', 'ATIVO', NULL),

('Bruno Henrique', '11111111107', '123456795', '1985-12-03', 'M', 'CASADO',
 'bruno@metalsul.com', '4730001007', '47990001007', 'Supervisor', 'Produção', 4800.00, '2018-07-16', NULL, 'Tarde', 'ATIVO', NULL),

('Camila Rodrigues', '11111111108', '123456796', '1998-08-25', 'F', 'SOLTEIRA',
 'camila@metalsul.com', '4730001008', '47990001008', 'Estoquista', 'Estoque', 2900.00, '2023-06-05', NULL, 'Manhã', 'ATIVO', NULL),

('Diego Ferreira', '11111111109', '123456797', '1991-04-11', 'M', 'SOLTEIRO',
 'diego@metalsul.com', '4730001009', '47990001009', 'Técnico', 'Manutenção', 3900.00, '2020-09-21', NULL, 'Noite', 'ATIVO', NULL),

('Patricia Almeida', '11111111110', '123456798', '1994-10-07', 'F', 'CASADA',
 'patricia@metalsul.com', '4730001010', '47990001010', 'Coordenadora', 'Logística', 5200.00, '2020-11-02', NULL, 'Comercial', 'ATIVO', NULL);


-- ==========================================================
-- USUARIO
-- ==========================================================

INSERT INTO usuario
(usuario, senha_hash, nivel_acesso, ultimo_login, ativo, id_funcionario)
VALUES
('carlos.silva', 'hash_001', 'ADMIN', '2026-08-10 08:00:00', TRUE, 1),
('ana.souza', 'hash_002', 'GERENTE', '2026-08-10 08:15:00', TRUE, 2),
('marcos.lima', 'hash_003', 'OPERADOR', '2026-08-10 09:00:00', TRUE, 3),
('juliana.martins', 'hash_004', 'VENDAS', '2026-08-10 09:30:00', TRUE, 4),
('rafael.oliveira', 'hash_005', 'COMPRAS', '2026-08-10 08:45:00', TRUE, 5),
('fernanda.costa', 'hash_006', 'GERENTE', NULL, TRUE, 6),
('bruno.henrique', 'hash_007', 'OPERADOR', '2026-08-09 14:00:00', TRUE, 7),
('camila.rodrigues', 'hash_008', 'ESTOQUE', '2026-08-10 07:50:00', TRUE, 8),
('diego.ferreira', 'hash_009', 'OPERADOR', '2026-08-09 22:00:00', TRUE, 9),
('patricia.almeida', 'hash_010', 'GERENTE', '2026-08-10 10:00:00', TRUE, 10);


-- ==========================================================
-- CLIENTE
-- ==========================================================

INSERT INTO cliente
(tipo_cliente, nome, cpf_cnpj, inscricao_estadual, email,
 telefone, celular, cep, endereco, numero, complemento,
 bairro, cidade, estado, pais, limite_credito, data_cadastro,
 status, observacoes)
VALUES
('PJ', 'Metalúrgica Brasil Ltda', '10000000000101', '123456789', 'contato@metalbrasil.com', '4730010001', '47991000001', '89200001', 'Rua Industrial', '100', NULL, 'Centro', 'Jaraguá do Sul', 'SC', 'Brasil', 50000.00, '2026-01-10', 'ATIVO', NULL),
('PJ', 'Indústria Forte Ltda', '10000000000202', '123456790', 'contato@industriaforte.com', '4730010002', '47991000002', '89200002', 'Rua das Indústrias', '200', NULL, 'Vila Nova', 'Joinville', 'SC', 'Brasil', 40000.00, '2026-01-12', 'ATIVO', NULL),
('PJ', 'Ferragens Sul Ltda', '10000000000303', '123456791', 'contato@ferragensul.com', '4730010003', '47991000003', '89200003', 'Rua Principal', '300', NULL, 'Centro', 'Guaramirim', 'SC', 'Brasil', 30000.00, '2026-01-15', 'ATIVO', NULL),
('PF', 'João da Silva', '11111111111', NULL, 'joao@email.com', '4730010004', '47991000004', '89200004', 'Rua A', '40', NULL, 'Centro', 'Jaraguá do Sul', 'SC', 'Brasil', 5000.00, '2026-02-01', 'ATIVO', NULL),
('PJ', 'Mecânica Horizonte Ltda', '10000000000505', '123456793', 'contato@mecanicahorizonte.com', '4730010005', '47991000005', '89200005', 'Rua B', '500', NULL, 'Nereu Ramos', 'Jaraguá do Sul', 'SC', 'Brasil', 25000.00, '2026-02-10', 'ATIVO', NULL),
('PF', 'Pedro Martins', '22222222222', NULL, 'pedro@email.com', '4730010006', '47991000006', '89200006', 'Rua C', '60', NULL, 'Centro', 'Schroeder', 'SC', 'Brasil', 3000.00, '2026-02-15', 'ATIVO', NULL),
('PJ', 'Auto Peças Norte Ltda', '10000000000707', '123456795', 'contato@autopecasnorte.com', '4730010007', '47991000007', '89200007', 'Rua D', '700', NULL, 'São Luís', 'Jaraguá do Sul', 'SC', 'Brasil', 35000.00, '2026-03-01', 'ATIVO', NULL),
('PJ', 'Construtora Alpha Ltda', '10000000000808', '123456796', 'contato@alpha.com', '4730010008', '47991000008', '89200008', 'Rua E', '800', NULL, 'Centro', 'Blumenau', 'SC', 'Brasil', 45000.00, '2026-03-05', 'ATIVO', NULL),
('PF', 'Lucas Ferreira', '33333333333', NULL, 'lucas@email.com', '4730010009', '47991000009', '89200009', 'Rua F', '90', NULL, 'Centro', 'Corupá', 'SC', 'Brasil', 4000.00, '2026-03-10', 'ATIVO', NULL),
('PJ', 'Equipamentos União Ltda', '10000000001010', '123456798', 'contato@equipamentosuniao.com', '4730010010', '47991000010', '89200010', 'Rua G', '1000', NULL, 'Industrial', 'Joinville', 'SC', 'Brasil', 60000.00, '2026-03-15', 'ATIVO', NULL);


-- ==========================================================
-- FORNECEDOR
-- ==========================================================

INSERT INTO fornecedor
(razao_social, nome_fantasia, cnpj, inscricao_estadual,
 email, telefone, celular, site, cep, endereco, numero,
 complemento, bairro, cidade, estado, pais, nome_contato,
 cargo_contato, status, observacoes)
VALUES
('Aços Brasil Ltda', 'Aços Brasil', '20000000000101', '987654321', 'contato@acosbrasil.com', '4730020001', '47992000001', 'www.acosbrasil.com', '89210001', 'Rua Aço', '100', NULL, 'Industrial', 'Joinville', 'SC', 'Brasil', 'Carlos Souza', 'Vendedor', 'ATIVO', NULL),
('Ferramentas Pro Ltda', 'Ferramentas Pro', '20000000000202', '987654322', 'contato@ferramentaspro.com', '4730020002', '47992000002', 'www.ferramentaspro.com', '89210002', 'Rua Ferramentas', '200', NULL, 'Centro', 'Jaraguá do Sul', 'SC', 'Brasil', 'Marcos Lima', 'Gerente', 'ATIVO', NULL),
('Metal Forte S.A.', 'Metal Forte', '20000000000303', '987654323', 'contato@metalforte.com', '4730020003', '47992000003', 'www.metalforte.com', '89210003', 'Rua Metal', '300', NULL, 'Industrial', 'Guaramirim', 'SC', 'Brasil', 'Paulo Costa', 'Vendedor', 'ATIVO', NULL),
('Parafusos União Ltda', 'Parafusos União', '20000000000404', '987654324', 'contato@parafusosuniao.com', '4730020004', '47992000004', NULL, '89210004', 'Rua União', '400', NULL, 'Centro', 'Jaraguá do Sul', 'SC', 'Brasil', 'André Silva', 'Vendedor', 'ATIVO', NULL),
('Máquinas Industrial Ltda', 'Máquinas Industrial', '20000000000505', '987654325', 'contato@maquinasindustrial.com', '4730020005', '47992000005', NULL, '89210005', 'Rua Máquinas', '500', NULL, 'Industrial', 'Joinville', 'SC', 'Brasil', 'Roberto Alves', 'Diretor', 'ATIVO', NULL),
('Tintas Sul Ltda', 'Tintas Sul', '20000000000606', '987654326', 'contato@tinassul.com', '4730020006', '47992000006', NULL, '89210006', 'Rua das Tintas', '600', NULL, 'Centro', 'Blumenau', 'SC', 'Brasil', 'Felipe Costa', 'Vendedor', 'ATIVO', NULL),
('EPIs Segurança Ltda', 'EPIs Segurança', '20000000000707', '987654327', 'contato@epis.com', '4730020007', '47992000007', NULL, '89210007', 'Rua Segurança', '700', NULL, 'Industrial', 'Schroeder', 'SC', 'Brasil', 'Renato Lima', 'Vendedor', 'ATIVO', NULL),
('Rolamentos Brasil Ltda', 'Rolamentos Brasil', '20000000000808', '987654328', 'contato@rolamentosbrasil.com', '4730020008', '47992000008', NULL, '89210008', 'Rua Rolamentos', '800', NULL, 'Centro', 'Joinville', 'SC', 'Brasil', 'Eduardo Silva', 'Gerente', 'ATIVO', NULL),
('Cabos Elétricos Ltda', 'Cabos Elétricos', '20000000000909', '987654329', 'contato@caboseletricos.com', '4730020009', '47992000009', NULL, '89210009', 'Rua Elétrica', '900', NULL, 'Industrial', 'Jaraguá do Sul', 'SC', 'Brasil', 'Gustavo Lima', 'Vendedor', 'ATIVO', NULL),
('Soldas Brasil Ltda', 'Soldas Brasil', '20000000001010', '987654330', 'contato@soldasbrasil.com', '4730020010', '47992000010', NULL, '89210010', 'Rua Solda', '1000', NULL, 'Industrial', 'Guaramirim', 'SC', 'Brasil', 'Ricardo Souza', 'Vendedor', 'ATIVO', NULL);


-- ==========================================================
-- CATEGORIA_PRODUTO
-- ==========================================================

INSERT INTO categoria_produto
(nome, descricao, ativo)
VALUES
('Ferramentas', 'Ferramentas manuais e industriais', TRUE),
('Parafusos', 'Parafusos e elementos de fixação', TRUE),
('Chapas', 'Chapas metálicas', TRUE),
('Tubos', 'Tubos metálicos', TRUE),
('Rolamentos', 'Rolamentos industriais', TRUE),
('EPIs', 'Equipamentos de proteção individual', TRUE),
('Tintas', 'Tintas e materiais de pintura', TRUE),
('Cabos', 'Cabos elétricos', TRUE),
('Soldas', 'Materiais para soldagem', TRUE),
('Máquinas', 'Máquinas e equipamentos industriais', TRUE);


-- ==========================================================
-- PRODUTO
-- ==========================================================

INSERT INTO produto
(codigo, codigo_barras, descricao, unidade_medida, marca, modelo,
 fabricante, peso, altura, largura, comprimento, cor,
 preco_custo, preco_venda, margem_lucro, estoque_atual,
 estoque_minimo, estoque_maximo, localizacao, lote,
 data_fabricacao, data_validade, data_cadastro, ativo,
 id_categoria, id_fornecedor)
VALUES
('PROD001', '7890000000011', 'Chapa de aço 2mm', 'UN', 'Gerdau', 'CH2', 'Aços Brasil', 25.500, 2.00, 100.00, 200.00, 'Cinza', 150.00, 220.00, 46.67, 100, 20, 300, 'A01', 'L001', '2026-01-10', NULL, '2026-01-15', TRUE, 3, 1),

('PROD002', '7890000000022', 'Parafuso sextavado M10', 'UN', 'FixPro', 'M10', 'Parafusos União', 0.050, 2.00, 2.00, 5.00, 'Prata', 0.80, 1.50, 87.50, 1000, 200, 3000, 'A02', 'L002', '2026-01-12', NULL, '2026-01-15', TRUE, 2, 4),

('PROD003', '7890000000033', 'Tubo aço carbono 2m', 'UN', 'Metal Forte', 'TC02', 'Metal Forte', 15.000, 5.00, 5.00, 200.00, 'Preto', 80.00, 120.00, 50.00, 200, 30, 500, 'B01', 'L003', '2026-01-20', NULL, '2026-01-22', TRUE, 4, 3),

('PROD004', '7890000000044', 'Rolamento industrial 6205', 'UN', 'SKF', '6205', 'Rolamentos Brasil', 0.350, 5.00, 5.00, 2.00, 'Prata', 35.00, 55.00, 57.14, 150, 20, 400, 'B02', 'L004', '2026-02-01', NULL, '2026-02-02', TRUE, 5, 8),

('PROD005', '7890000000055', 'Capacete de segurança', 'UN', '3M', 'H700', 'EPIs Segurança', 0.450, 20.00, 25.00, 30.00, 'Amarelo', 25.00, 45.00, 80.00, 80, 15, 200, 'C01', 'L005', '2026-02-05', NULL, '2026-02-06', TRUE, 6, 7),

('PROD006', '7890000000066', 'Tinta industrial azul 18L', 'LATA', 'Suvinil', 'IND18', 'Tintas Sul', 18.500, 35.00, 30.00, 30.00, 'Azul', 120.00, 180.00, 50.00, 50, 10, 100, 'C02', 'L006', '2026-02-10', '2028-02-10', '2026-02-11', TRUE, 7, 6),

('PROD007', '7890000000077', 'Cabo elétrico 10mm', 'METRO', 'Prysmian', '10MM', 'Cabos Elétricos', 0.120, 1.00, 1.00, 100.00, 'Preto', 8.00, 13.00, 62.50, 500, 100, 1000, 'D01', 'L007', '2026-02-15', NULL, '2026-02-16', TRUE, 8, 9),

('PROD008', '7890000000088', 'Eletrodo para solda 2.5mm', 'KG', 'ESAB', 'E6013', 'Soldas Brasil', 1.000, 10.00, 10.00, 30.00, 'Cinza', 18.00, 30.00, 66.67, 100, 20, 250, 'D02', 'L008', '2026-02-20', NULL, '2026-02-21', TRUE, 9, 10),

('PROD009', '7890000000099', 'Furadeira industrial', 'UN', 'Bosch', 'GBM20', 'Máquinas Industrial', 5.500, 25.00, 10.00, 35.00, 'Azul', 450.00, 650.00, 44.44, 20, 5, 50, 'E01', 'L009', '2026-03-01', NULL, '2026-03-02', TRUE, 1, 5),

('PROD010', '7890000000100', 'Chapa de aço 5mm', 'UN', 'Gerdau', 'CH5', 'Aços Brasil', 62.000, 5.00, 100.00, 200.00, 'Cinza', 350.00, 500.00, 42.86, 60, 10, 150, 'E02', 'L010', '2026-03-05', NULL, '2026-03-06', TRUE, 3, 1);


-- ==========================================================
-- PEDIDO_COMPRA
-- ==========================================================

INSERT INTO pedido_compra
(numero_pedido, data_emissao, data_prevista_entrega, data_recebimento,
 valor_total, forma_pagamento, status, observacoes,
 id_fornecedor, id_funcionario)
VALUES
('PC0001', '2026-04-01', '2026-04-10', '2026-04-09', 15000.00, 'PIX', 'RECEBIDO', NULL, 1, 5),
('PC0002', '2026-04-03', '2026-04-15', NULL, 8500.00, 'BOLETO', 'EM_TRANSITO', NULL, 2, 5),
('PC0003', '2026-04-05', '2026-04-18', NULL, 6200.00, 'BOLETO', 'APROVADO', NULL, 3, 5),
('PC0004', '2026-04-08', '2026-04-20', NULL, 4300.00, 'PIX', 'ABERTO', NULL, 4, 5),
('PC0005', '2026-04-10', '2026-04-25', '2026-04-24', 12000.00, 'TRANSFERENCIA', 'RECEBIDO', NULL, 5, 5),
('PC0006', '2026-04-12', '2026-04-28', NULL, 5000.00, 'BOLETO', 'APROVADO', NULL, 6, 5),
('PC0007', '2026-04-15', '2026-04-30', NULL, 3500.00, 'PIX', 'ABERTO', NULL, 7, 5),
('PC0008', '2026-04-18', '2026-05-02', NULL, 7800.00, 'BOLETO', 'EM_TRANSITO', NULL, 8, 5),
('PC0009', '2026-04-20', '2026-05-05', '2026-05-04', 9000.00, 'TRANSFERENCIA', 'RECEBIDO', NULL, 9, 5),
('PC0010', '2026-04-22', '2026-05-10', NULL, 11000.00, 'BOLETO', 'CANCELADO', 'Pedido cancelado pelo fornecedor', 10, 5);


-- ==========================================================
-- ITEM_PEDIDO_COMPRA
-- ==========================================================

INSERT INTO item_pedido_compra
(quantidade, valor_unitario, desconto, subtotal,
 id_pedido_compra, id_produto)
VALUES
(100, 150.00, 0, 15000.00, 1, 1),
(500, 17.00, 0, 8500.00, 2, 2),
(80, 77.50, 0, 6200.00, 3, 3),
(100, 43.00, 0, 4300.00, 4, 4),
(300, 40.00, 0, 12000.00, 5, 5),
(30, 166.67, 0, 5000.00, 6, 6),
(250, 14.00, 0, 3500.00, 7, 7),
(260, 30.00, 0, 7800.00, 8, 8),
(20, 450.00, 0, 9000.00, 9, 9),
(20, 550.00, 0, 11000.00, 10, 10);


-- ==========================================================
-- PEDIDO_VENDA
-- ==========================================================

INSERT INTO pedido_venda
(numero_pedido, data_venda, valor_total, desconto,
 forma_pagamento, status, observacoes,
 id_cliente, id_funcionario)
VALUES
('PV0001', '2026-05-01', 2200.00, 0, 'PIX', 'FINALIZADO', NULL, 1, 4),
('PV0002', '2026-05-03', 1500.00, 50.00, 'BOLETO', 'FATURADO', NULL, 2, 4),
('PV0003', '2026-05-05', 3600.00, 0, 'CARTAO', 'FINALIZADO', NULL, 3, 4),
('PV0004', '2026-05-08', 4500.00, 100.00, 'PIX', 'FINALIZADO', NULL, 4, 4),
('PV0005', '2026-05-10', 5500.00, 0, 'BOLETO', 'FATURADO', NULL, 5, 4),
('PV0006', '2026-05-12', 900.00, 0, 'PIX', 'ABERTO', NULL, 6, 4),
('PV0007', '2026-05-15', 2600.00, 100.00, 'CARTAO', 'FINALIZADO', NULL, 7, 4),
('PV0008', '2026-05-18', 1300.00, 0, 'PIX', 'FINALIZADO', NULL, 8, 4),
('PV0009', '2026-05-20', 6500.00, 500.00, 'BOLETO', 'FATURADO', NULL, 9, 4),
('PV0010', '2026-05-22', 5000.00, 0, 'PIX', 'CANCELADO', 'Venda cancelada pelo cliente', 10, 4);


-- ==========================================================
-- ITEM_PEDIDO_VENDA
-- ==========================================================

INSERT INTO item_pedido_venda
(quantidade, valor_unitario, desconto, subtotal,
 id_pedido_venda, id_produto)
VALUES
(10, 220.00, 0, 2200.00, 1, 1),
(1000, 1.50, 0, 1500.00, 2, 2),
(30, 120.00, 0, 3600.00, 3, 3),
(100, 45.00, 0, 4500.00, 4, 4),
(100, 55.00, 0, 5500.00, 5, 5),
(5, 180.00, 0, 900.00, 6, 6),
(200, 13.00, 0, 2600.00, 7, 7),
(10, 130.00, 0, 1300.00, 8, 8),
(10, 650.00, 0, 6500.00, 9, 9),
(10, 500.00, 0, 5000.00, 10, 10);